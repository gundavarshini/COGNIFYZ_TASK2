 const express = require("express");

const app = express();

const PORT = 3001;


// Set EJS as view engine
app.set("view engine", "ejs");


// Read form data
app.use(express.urlencoded({ extended: true }));


// Temporary server-side storage
const students = [];


// Home page
app.get("/", (req, res) => {

    res.render("index");

});


// Registration endpoint
app.post("/register", (req, res) => {

    const {
        name,
        email,
        phone,
        age,
        dob,
        gender,
        course,
        address,
        password,
        confirmPassword,
        terms
    } = req.body;


    // =========================
    // SERVER-SIDE VALIDATION
    // =========================

    if (!name || name.trim().length < 3) {

        return res.render("error", {
            message: "Name must contain at least 3 characters."
        });

    }


    // Email validation

    const emailPattern =
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!email || !emailPattern.test(email)) {

        return res.render("error", {
            message: "Please enter a valid email address."
        });

    }


    // Phone validation

    const phonePattern = /^[0-9]{10}$/;

    if (!phone || !phonePattern.test(phone)) {

        return res.render("error", {
            message: "Phone number must contain exactly 10 digits."
        });

    }


    // Age validation

    const studentAge = Number(age);

    if (
        !age ||
        isNaN(studentAge) ||
        studentAge < 17 ||
        studentAge > 60
    ) {

        return res.render("error", {
            message: "Age must be between 17 and 60."
        });

    }


    // Date of birth validation

    if (!dob) {

        return res.render("error", {
            message: "Please select your date of birth."
        });

    }


    // Gender validation

    if (!gender) {

        return res.render("error", {
            message: "Please select your gender."
        });

    }


    // Course validation

    if (!course) {

        return res.render("error", {
            message: "Please select a course."
        });

    }


    // Address validation

    if (!address || address.trim().length < 10) {

        return res.render("error", {
            message: "Address must contain at least 10 characters."
        });

    }


    // Password validation

    if (!password || password.length < 6) {

        return res.render("error", {
            message: "Password must contain at least 6 characters."
        });

    }


    // Confirm password

    if (password !== confirmPassword) {

        return res.render("error", {
            message: "Passwords do not match."
        });

    }


    // Terms validation

    if (!terms) {

        return res.render("error", {
            message: "Please accept the terms and conditions."
        });

    }


    // =========================
    // TEMPORARY STORAGE
    // =========================

    const student = {

        id: students.length + 1,

        name: name.trim(),

        email: email.trim(),

        phone: phone,

        age: studentAge,

        dob: dob,

        gender: gender,

        course: course,

        address: address.trim()

    };


    // Store validated student

    students.push(student);


    // Display stored data in terminal

    console.log("Student Registered:");

    console.log(student);

    console.log("Total Students:", students.length);


    // Send success page

    res.render("success", {
        student: student
    });

});


// Start server

app.listen(PORT, () => {

    console.log(
        `Task 2 server running at http://localhost:${PORT}`
    );

});